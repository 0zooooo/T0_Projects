const searchBtn = document.getElementById('search-btn');
const cityInput = document.getElementById('city-input');
const resultContainer = document.getElementById('result-container');
const loadingDiv = document.getElementById('loading');
const loadingText = document.getElementById('loading-text');
const errorMsg = document.getElementById('error-msg');

const cityNameEl = document.getElementById('city-name');
const countryEl = document.getElementById('country');
const tempEl = document.getElementById('temperature');
const windEl = document.getElementById('wind');
const timeEl = document.getElementById('local-time');
const cityImgEl = document.getElementById('city-image');
const weatherDescEl = document.getElementById('weather-desc');
const weatherIconEl = document.getElementById('weather-icon');

const cityMap = {
    '서울': 'Seoul',
    '서울시': 'Seoul',
    '부산': 'Busan',
    '부산시': 'Busan',
    '인천': 'Incheon',
    '대구': 'Daegu',
    '대전': 'Daejeon',
    '광주': 'Gwangju',
    '울산': 'Ulsan',
    '수원': 'Suwon',
    '제주': 'Jeju',
    '제주시': 'Jeju',
    '용인': 'Yongin',
    '용인시': 'Yongin',
    '성남': 'Seongnam',
    '성남시': 'Seongnam'
};

function getWeatherStatus(code) {
    if (code === 0) return { text: "쾌청함", icon: "☀️" };
    if (code >= 1 && code <= 3) return { text: "구름 조금/흐림", icon: "☁️" };
    if (code >= 45 && code <= 48) return { text: "안개", icon: "🌫️" };
    if (code >= 51 && code <= 67) return { text: "비", icon: "🌧️" };
    if (code >= 71 && code <= 77) return { text: "눈", icon: "❄️" };
    if (code >= 80 && code <= 99) return { text: "소나기/폭우", icon: "⛈️" };
    return { text: "흐림", icon: "☁️" };
}

async function searchCity() {
    let inputCity = cityInput.value.trim();
    
    if (!inputCity) {
        alert("도시 이름을 입력해주세요!");
        return;
    }

    resultContainer.classList.add('hidden');
    errorMsg.classList.add('hidden');
    loadingDiv.classList.remove('hidden');
    loadingText.textContent = `🔍 '${inputCity}' 찾는 중...`;

    try {
        let searchName = cityMap[inputCity] || inputCity;

        let geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchName)}&count=10&language=ko&format=json`;
        let geoRes = await fetch(geoUrl);
        let geoData = await geoRes.json();

        if (!geoData.results || geoData.results.length === 0) {
            if (/^[가-힣]{2}$/.test(inputCity)) {
                searchName = inputCity + "시";
                geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchName)}&count=10&language=ko&format=json`;
                geoRes = await fetch(geoUrl);
                geoData = await geoRes.json();
            }
        }

        if (!geoData.results || geoData.results.length === 0) {
            throw new Error(`'${inputCity}'을(를) 찾을 수 없습니다.`);
        }

        let location = geoData.results.find(item => item.country_code === 'KR');
        if (!location) location = geoData.results[0];

        const { latitude, longitude, country } = location;

        loadingText.textContent = `🌡️ 날씨 정보 확인 중...`;
        const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&timezone=auto`;
        const weatherRes = await fetch(weatherUrl);
        const weatherData = await weatherRes.json();

        loadingText.textContent = `📸 도시 사진 찾는 중...`;
        
        const wikiUrl = `https://ko.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(inputCity)}&redirects=1&prop=pageimages&pithumbsize=600&format=json&origin=*`;
        
        let imageUrl = null;
        try {
            const wikiRes = await fetch(wikiUrl);
            const wikiData = await wikiRes.json();
            
            if (wikiData.query && wikiData.query.pages) {
                const pages = wikiData.query.pages;
                const firstPageId = Object.keys(pages)[0];
                if (firstPageId !== "-1" && pages[firstPageId].thumbnail) {
                    imageUrl = pages[firstPageId].thumbnail.source;
                }
            }
        } catch (imgErr) {
            console.log("이미지 로딩 실패");
        }

        cityNameEl.textContent = inputCity;
        countryEl.textContent = country || "Unknown";

        const current = weatherData.current_weather;
        tempEl.textContent = current.temperature;
        windEl.textContent = current.windspeed;
        timeEl.textContent = current.time.replace('T', ' ').slice(11, 16);

        const status = getWeatherStatus(current.weathercode);
        weatherDescEl.textContent = status.text;
        weatherIconEl.textContent = status.icon;

        if (imageUrl) {
            cityImgEl.src = imageUrl;
        } else {
            cityImgEl.src = `https://placehold.co/600x400/87CEEB/ffffff?text=${encodeURIComponent(inputCity)}`;
        }

        loadingDiv.classList.add('hidden');
        resultContainer.classList.remove('hidden');

    } catch (error) {
        console.error(error);
        loadingDiv.classList.add('hidden');
        errorMsg.textContent = `⚠️ 오류: ${error.message}`;
        errorMsg.classList.remove('hidden');
    }
}

searchBtn.addEventListener('click', searchCity);
cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') searchCity();
});